package com.gontuseries.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.gontu.entity.Student;

@Controller
public class MehodlevelModelAttribute {

	
	@RequestMapping(value="/AdmissionformCO")
	public ModelAndView getadmission() {
		
		ModelAndView mv=new ModelAndView("AdmissionformCO.jsp");
		return mv;
		}
	
	@ModelAttribute
	public void addingCommonObjects(Model mv)
	{
		mv.addAttribute("Collegename", "ZEAL College of Engineering,PUNE");
		mv.addAttribute("form", "Student Admission form for Engineering courses");

		
	}
	 
	
	@RequestMapping(value="/SubmitformCO",method =RequestMethod.POST)
	public ModelAndView Submitform(@Valid @ModelAttribute("student") Student student,BindingResult result) {
		
		if(result.hasErrors())
		{
			ModelAndView mv=new ModelAndView("AdmissionformCO.jsp");
			return mv;
		}
		ModelAndView mv=new ModelAndView("methodlevelmodattr.jsp");
		mv.addObject("ADmissionsuccess", "Details submitted by  you  is ");
		
		
		return mv;
		}
	
	
	
	
	
}
