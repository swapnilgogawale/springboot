package com.gontu.entity;

import java.util.ArrayList;


import java.util.Date;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@NoArgsConstructor
@AllArgsConstructor
@Data

public class Student {

	@Pattern( regexp = "[0-9]")
   private String stdname;
   
   @Size(min=2,max=20,message = "Enter the size between 2 and 20 range")
    private String stdhobby;
	private Long mobno;
	private Date DOB;
	private ArrayList<String> studentsskills;
	/*
	 * public Long getMobno() { return mobno; } public void setMobno(Long mobno) {
	 * this.mobno = mobno; } public Date getDOB() { return DOB; } public void
	 * setDOB(Date dOB) { DOB = dOB; } public ArrayList<String> getStudentsskills()
	 * { return studentsskills; } public void setStudentsskills(ArrayList<String>
	 * studentsskills) { this.studentsskills = studentsskills; } public String
	 * getStdname() { return stdname; } public void setStdname(String stdname) {
	 * this.stdname = stdname; } public String getStdhobby() { return stdhobby; }
	 * public void setStdhobby(String stdhobby) { this.stdhobby = stdhobby; }
	 * 
	 */	
	
	
}
