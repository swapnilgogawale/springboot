package com.gontuseries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GontuseriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
